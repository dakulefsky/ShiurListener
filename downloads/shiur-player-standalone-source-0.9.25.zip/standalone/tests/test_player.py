import pathlib,sys,tempfile,unittest
ROOT=pathlib.Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'app'))
from engine import Player
from controller import LibraryController
class Audio:
 def __init__(self):self.position=0;self.status='stopped';self.duration=120
 def load(self,path):self.path=path;self.position=0;self.status='stopped'
 def play(self):self.status='playing'
 def pause(self):self.status='paused'
 def stop(self):self.status='stopped'
 def seek(self,value):self.position=value
 def speed(self,value):self.rate=value
 def volume(self,value):self.level=value
 def state(self):return {'position':self.position,'duration':self.duration,'status':self.status}
class Tests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.root=pathlib.Path(self.tmp.name).resolve();self.audio=self.root/'audio';self.audio.mkdir();(self.audio/'01.wav').write_bytes(b'fake');(self.audio/'02.mp3').write_bytes(b'fake')
  self.backend=Audio();self.player=Player(self.audio,self.root/'data',self.backend);self.library=LibraryController(self.player)
 def tearDown(self):self.tmp.cleanup()
 def test_unreadable_saved_state_is_backed_up_and_recovers_positions(self):
  ident=self.player.tracks[0]['id']
  self.player.saved['tracks'][ident]={'position':42,'duration':120,'completed':False}
  self.player.persist()
  raw=__import__('json').loads(self.player.file.read_text(encoding='utf-8'))
  raw['speechEnhancementStrength']=999
  self.player.file.write_text(__import__('json').dumps(raw),encoding='utf-8')
  restored=Player(None,self.root/'data',Audio())
  self.assertEqual(restored.saved['tracks'][ident]['position'],42)
  self.assertTrue(restored.saved['tracks'][ident]['position']==42)
  backups=list((self.root/'data').glob('state.json.recovery-*.bak'))
  self.assertEqual(len(backups),1)
  self.assertEqual(__import__('json').loads(backups[0].read_text(encoding='utf-8'))['speechEnhancementStrength'],999)
 def test_audio_enhancement_settings_validate_and_persist(self):
  settings={'bass':-2,'body':1,'clarity':4,'treble':2}
  self.player.command({'op':'audio_enhancement','value':settings})
  self.assertEqual(self.player.saved['audioEnhancement'],settings)
  restored=Player(None,self.root/'data',Audio())
  self.assertEqual(restored.saved['audioEnhancement'],settings)
  with self.assertRaisesRegex(ValueError,'between -6 and \\+6'):
   self.player.command({'op':'audio_enhancement','value':{'clarity':8}})
  with self.assertRaisesRegex(ValueError,'object'):
   self.player.command({'op':'audio_enhancement','value':'loud'})
 def test_enhanced_cache_is_optional_and_original_is_preserved(self):
  ident=self.player.tracks[0]['id'];source=self.player.paths[ident];original=source.read_bytes()
  cache=self.player.speech_cache_path(ident);cache.parent.mkdir(parents=True);cache.write_bytes(b'enhanced copy')
  self.player.load(ident,autoplay=False)
  self.assertEqual(pathlib.Path(self.backend.path),source)
  self.player.command({'op':'speech_enhancement_enabled','value':True})
  self.assertEqual(pathlib.Path(self.backend.path),cache)
  self.assertTrue(self.player.saved['speechEnhancementEnabled'])
  self.assertEqual(source.read_bytes(),original)
  self.player.command({'op':'speech_enhancement_enabled','value':False})
  self.assertEqual(pathlib.Path(self.backend.path),source)
  self.assertFalse(self.player.saved['speechEnhancementEnabled'])
  restored=Player(None,self.root/'data',Audio())
  self.assertFalse(restored.saved['speechEnhancementEnabled'])

 def test_speech_suppression_strength_is_persisted_and_separates_cache(self):
  ident=self.player.tracks[0]['id'];balanced=self.player.speech_cache_path(ident)
  self.player.saved['speechEnhancementStrength']=50;self.player.persist()
  strong=self.player.speech_cache_path(ident)
  self.assertNotEqual(balanced,strong)
  restored=Player(None,self.root/'data',Audio())
  self.assertEqual(restored.saved['speechEnhancementStrength'],50)
 def test_next_day_open_and_play_needs_no_connection(self):
  self.library.play();self.player.tick();self.backend.position=65.432;self.player.command({'op':'pause'})
  backend=Audio();restored=Player(None,self.root/'data',backend);view=LibraryController(restored)
  self.assertEqual(restored.root,self.audio);self.assertEqual(restored.snapshot()['position'],65.432)
  view.play();restored.tick();self.assertEqual(backend.status,'playing');self.assertEqual(backend.position,65.432)
 def test_separate_positions_for_two_recordings(self):
  ids=[t['id'] for t in self.player.tracks]
  self.library.selected=ids[0];self.library.play();self.player.tick();self.backend.position=65.432
  self.library.selected=ids[1];self.library.play(force=True);self.player.tick();self.backend.position=23.789;self.player.command({'op':'pause'})
  self.library.selected=ids[0];self.library.play();self.player.tick();self.assertEqual(self.backend.position,65.432)
  self.assertEqual(self.player.saved['tracks'][ids[1]]['position'],23.789)
 def test_each_recording_restores_speed_after_switch_and_restart(self):
  a,b=[t['id'] for t in self.player.tracks]
  self.player.load(a,autoplay=True);self.player.tick()
  self.player.command({'op':'speed','value':1.5})
  self.player.load(b,autoplay=True);self.player.tick();self.assertEqual(self.backend.rate,1)
  self.player.command({'op':'speed_cycle'});self.player.command({'op':'speed_cycle'})
  self.assertEqual(self.backend.rate,2)
  self.player.load(a,autoplay=True);self.player.tick();self.assertEqual(self.backend.rate,1.5)
  restored=Player(None,self.root/'data',Audio())
  restored.load(b,autoplay=True);restored.tick();self.assertEqual(restored.backend.rate,2)
  restored.load(a,autoplay=False);restored.tick();self.assertEqual(restored.backend.rate,1.5)
  self.assertEqual(restored.backend.status,'paused')
 def test_finished_tracks_and_near_end_are_distinguished(self):
  ids=[t['id'] for t in self.player.tracks]
  self.library.selected=ids[0];self.library.play();self.player.tick();self.backend.position=119.9;self.player.command({'op':'pause'})
  self.library.selected=ids[1];self.library.play(force=True);self.player.tick();self.backend.status='ended';self.player.tick()
  self.library.view='continue';self.assertEqual([t['id'] for t in self.library.tracks()],[ids[0]])
  self.library.selected=ids[1];self.library.reset();self.assertFalse(self.player.saved['tracks'][ids[1]]['completed'])
  self.assertEqual(self.player.saved['tracks'][ids[0]]['position'],119.9)
 def test_collections_create_subfolders_move_audio_and_preserve_library_state(self):
  self.assertEqual(self.player.saved['folders'],[])
  original=self.player.tracks[0]['id'];self.library.selected=original
  self.library.play();self.player.tick();self.backend.position=37.5;self.library.mark('Review')
  self.player.saved['queue']=[original,self.player.tracks[1]['id']]
  self.library.collection('folder_create','My series');folder=self.library.view
  self.assertTrue((self.audio/'My series').is_dir())
  self.library.assign_many([original],'My series')
  moved=next(t for t in self.player.tracks if t['name']=='01.wav')
  self.assertEqual(moved['source'],'My series/01.wav')
  self.assertFalse((self.audio/'01.wav').exists())
  self.assertTrue((self.audio/'My series'/'01.wav').is_file())
  self.assertNotIn(original,self.player.paths);self.assertIn(moved['id'],self.player.paths)
  self.assertEqual(self.player.saved['currentId'],moved['id'])
  self.assertEqual(self.player.active,moved['id'])
  self.assertEqual(self.player.saved['tracks'][moved['id']]['position'],37.5)
  self.assertEqual(self.player.saved['bookmarks'][moved['id']][0]['name'],'Review')
  self.assertEqual(self.player.saved['queue'][0],moved['id'])
  self.assertEqual(self.player.saved['folders'][0]['trackIds'],[moved['id']])
  self.player.tick();self.assertEqual(self.backend.position,37.5)
  self.library.collection('folder_rename','Renamed')
  self.assertTrue((self.audio/'Renamed'/'01.wav').is_file())
  self.assertFalse((self.audio/'My series').exists())
  self.library.collection('folder_delete')
  self.assertTrue((self.audio/'Renamed'/'01.wav').is_file())
  self.assertEqual(len(self.player.tracks),2)
 def test_moving_recording_to_another_collection_moves_file_and_reassigns_it(self):
  original=self.player.tracks[0]['id']
  self.library.assign_many([original],'First')
  first=self.player.saved['folders'][0]
  first_path=self.audio/'First'/'01.wav'
  self.assertTrue(first_path.is_file())
  moved=next(track['id'] for track in self.player.tracks if track['name']=='01.wav')
  self.library.assign_many([moved],'Second')
  second=self.player.saved['folders'][1]
  self.assertFalse(first_path.exists())
  self.assertTrue((self.audio/'Second'/'01.wav').is_file())
  self.assertEqual(first['trackIds'],[])
  self.assertEqual(second['trackIds'],[next(track['id'] for track in self.player.tracks if track['name']=='01.wav')])
 def test_bookmarks_are_local_and_survive_restart(self):
  self.library.play();self.player.tick();self.backend.position=32.456;self.library.mark('Review')
  mark=self.library.bookmarks()[0];self.assertEqual(mark['position'],32.456)
  restored=Player(None,self.root/'data',Audio());view=LibraryController(restored);self.assertEqual(view.bookmarks()[0]['name'],'Review')
  view.bookmark_action(mark['id']);restored.tick();self.assertEqual(restored.backend.position,32.456);self.assertEqual(restored.backend.status,'paused')
  view.bookmark_action(mark['id'],delete=True);self.assertEqual(view.bookmarks(),[])
 def test_reset_one_track_preserves_others(self):
  ids=[t['id'] for t in self.player.tracks];self.library.selected=ids[0];self.library.play();self.player.tick();self.backend.position=35
  self.player.saved['tracks'][ids[1]]={'position':23.789};self.library.reset()
  self.assertEqual(self.backend.status,'paused');self.assertEqual(self.backend.position,0);self.assertEqual(self.player.saved['tracks'][ids[1]]['position'],23.789)
 def test_rescan_finds_new_files_and_confines_symlinks(self):
  (self.audio/'new.mp3').write_bytes(b'fake');outside=self.root/'outside.wav';outside.write_bytes(b'fake');(self.audio/'escape.wav').symlink_to(outside)
  self.player.scan();self.assertEqual(len(self.player.tracks),3)
 def test_pause_after_auto_next_does_not_reload_the_old_selection(self):
  self.library.play();self.player.tick();first=self.player.saved['currentId'];self.library.selected=first
  self.player.saved['autoNext']=True;self.player.was_playing=True;self.backend.status='ended';self.backend.position=120
  self.player.tick();self.player.tick();current=self.player.saved['currentId'];self.assertNotEqual(first,current)
  self.library.play();self.assertEqual(self.backend.status,'paused');self.assertEqual(self.player.saved['currentId'],current)
 def test_search_does_not_block_pausing_current_recording(self):
  self.library.play();self.player.tick();self.library.query='no match';self.library.play();self.assertEqual(self.backend.status,'paused')
 def test_speed_skip_and_sleep_timer(self):
  self.player.command({'op':'language','value':'en'});self.library.play();self.player.tick()
  self.player.command({'op':'speed','value':1.5});self.assertEqual(self.backend.rate,1.5)
  for n in [10,15,60]:
   self.backend.position=10;self.player.command({'op':'skip_interval','value':n});self.player.command({'op':'skip','direction':1});self.assertEqual(self.backend.position,10+n)
  self.player.command({'op':'sleep_timer','minutes':15});self.player.sleep_deadline=0.01;self.player.tick();self.assertEqual(self.backend.status,'paused')
  restored=Player(None,self.root/'data',Audio());self.assertEqual(restored.saved['language'],'en')
 def test_skip_while_loading_uses_the_saved_position(self):
  ident=self.player.tracks[0]['id'];self.player.saved['tracks'][ident]={'position':65.432,'duration':120}
  self.player.load(ident,autoplay=True)
  self.assertEqual(self.backend.position,0)
  self.player.command({'op':'skip','direction':1})
  self.assertEqual(self.player.pending['position'],80.432)
  self.player.tick();self.assertEqual(self.backend.position,80.432)
 def test_batch_collection_validation_does_not_create_an_empty_collection(self):
  ident=self.player.tracks[0]['id']
  with self.assertRaises(ValueError):self.library.assign_many([ident,'missing'],'My series')
  with self.assertRaises(ValueError):self.library.assign_many([ident],'x'*161)
  self.assertEqual(self.player.saved['folders'],[])
 def test_mini_speed_bounces_and_survives_restart(self):
  self.library.play();self.player.tick();ident=self.player.active;self.backend.position=42.875
  rates=[]
  for _ in range(4):
   self.player.command({'op':'speed_cycle'});rates.append(self.backend.rate)
  self.assertEqual(rates,[1.5,2,.5,1]);self.assertEqual(self.backend.position,42.875)
  self.assertEqual(self.player.saved['tracks'][ident]['position'],42.875)
  self.player.command({'op':'speed_cycle'});self.player.command({'op':'speed_cycle'})
  restored=Player(None,self.root/'data',Audio());restored.command({'op':'speed_cycle'});self.assertEqual(restored.saved['speed'],.5)
  restored.saved['miniSpeedMiddle']=.5;restored.command({'op':'speed','value':1})
  rates=[restored.command({'op':'speed_cycle'})['speed'] for _ in range(4)];self.assertEqual(rates,[1.5,2,.5,1])
 def test_upgrade_corrects_existing_mini_speed_cycle(self):
  import json
  saved=dict(self.player.saved);saved.pop('halfSpeedCycleMigration',None)
  saved.update(miniSpeedMiddle=1.5,miniSpeedCycleIndex=2,speed=2)
  self.player.file.write_text(json.dumps(saved))
  restored=Player(None,self.root/'data',Audio())
  self.assertEqual(restored.command({'op':'speed_cycle'})['speed'],.5)
  self.assertEqual(restored.command({'op':'speed_cycle'})['speed'],1)
if __name__=='__main__':unittest.main(verbosity=2)
