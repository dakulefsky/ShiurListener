"""Exercise the real desktop toolkit, including persistence across a new window."""
import os,pathlib,sys,unittest
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]/'app'))
from window import PlayerWindow
from engine import Player
from controller import LibraryController
import test_player
@unittest.skipUnless(os.environ.get('DISPLAY') or sys.platform=='win32','Needs a desktop display')
class Tests(unittest.TestCase):
 def test_minimize_opens_bar_and_restore_hides_only_automatic_bar(self):
  fixture=test_player.Tests();fixture.setUp();window=None
  class Bar:
   def __init__(self):self.calls=[];self.hwnd=123;self.status='ready'
   def set_visible(self,visible):self.calls.append(visible);fixture.player.saved['floatingVisible']=visible
  try:
   bar=Bar();fixture.player.floating_bar=bar;fixture.player.saved['floatingVisible']=False
   window=PlayerWindow(fixture.player,fixture.library,lambda _:None)
   window.window_state_changed(True);window.window_state_changed(True)
   window.window_state_changed(False);self.assertEqual(bar.calls,[True,False])
   fixture.player.saved['floatingVisible']=True;window.window_state_changed(True);window.window_state_changed(False)
   self.assertEqual(bar.calls,[True,False,True])
   fixture.player.saved['miniOnMinimize']=False;window.window_state_changed(True);self.assertEqual(len(bar.calls),3)
  finally:
   if window:window.close()
   fixture.tearDown()
 def test_new_collection_assignment_is_one_operation(self):
  fixture=test_player.Tests();fixture.setUp();window=None
  try:
   window=PlayerWindow(fixture.player,fixture.library,lambda _:None)
   fixture.library.selected=fixture.player.tracks[0]['id'];window.assign_collection('My recordings')
   folders=fixture.player.saved['folders'];self.assertEqual(len(folders),1);self.assertEqual(folders[0]['trackIds'],[fixture.library.selected])
   window.assign_collection('my recordings');self.assertEqual(len(folders),1);self.assertEqual(len(folders[0]['trackIds']),1)
  finally:
   if window:window.close()
   fixture.tearDown()
 def test_custom_seek_and_volume_controls(self):
  from types import SimpleNamespace
  fixture=test_player.Tests();fixture.setUp();window=None
  try:
   fixture.library.play();fixture.player.tick()
   window=PlayerWindow(fixture.player,fixture.library,lambda _:None);window.root.update()
   window.seek.pointer(SimpleNamespace(x=window.seek.winfo_width()/2));window.seek_release(None)
   self.assertAlmostEqual(fixture.backend.position,60,delta=1)
   window.seek.step(1);self.assertGreater(fixture.backend.position,60)
   self.assertAlmostEqual(fixture.player.saved['tracks'][fixture.player.active]['position'],fixture.backend.position)
  finally:
   if window:window.close()
   fixture.tearDown()
 def test_multiple_resume_rows_and_reopen(self):
  fixture=test_player.Tests();fixture.setUp();window=None
  try:
   (fixture.audio/'03.wav').write_bytes(b'fake');fixture.player.scan();ids=[t['id'] for t in fixture.player.tracks]
   for ident,position in zip(ids,[65.432,23.789,119.9]):
    fixture.library.selected=ident;fixture.library.play(force=True);fixture.player.tick();fixture.backend.position=position;fixture.player.command({'op':'pause'})
   window=PlayerWindow(fixture.player,fixture.library,lambda _:None);window.root.update()
   self.assertEqual([window.tree.item(i,'values')[1] for i in ids],['1:05','0:23','1:59'])
   window.navigate('continue');window.root.update();self.assertEqual(list(window.tree.get_children()),ids[::-1])
   window.tree.selection_set(ids[0]);window.root.update();window.resume();fixture.player.tick();self.assertEqual(fixture.backend.position,65.432)
   window.query.set('03');window.root.update();self.assertEqual(list(window.tree.get_children()),[ids[2]])
   window.toggle();self.assertEqual(fixture.backend.status,'paused');window.close();window=None
   backend=test_player.Audio();player=Player(None,fixture.root/'data',backend);library=LibraryController(player);window=PlayerWindow(player,library,lambda _:None);window.root.update()
   for ident,position in zip(ids,[65.432,23.789,119.9]):
    window.tree.selection_set(ident);window.root.update();window.resume();player.tick();self.assertEqual(backend.position,position)
  finally:
   if window:window.close()
   fixture.tearDown()
if __name__=='__main__':unittest.main(verbosity=2)
