ShiurUI.enhance();ShiurLocale.apply();
